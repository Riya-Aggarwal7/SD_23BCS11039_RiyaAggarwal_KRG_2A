package com.project.roommate.service;

import com.project.roommate.dto.MatchDto;
import com.project.roommate.entity.Profile;

import java.util.List;

public interface MatchService {
    List<MatchDto> findMatchesForUser(String email);
    List<MatchDto> findMatchesForUserWithFilters(String email, String gender, Integer maxBudget, String city);
}
