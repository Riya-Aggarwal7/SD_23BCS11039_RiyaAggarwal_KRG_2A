package com.project.roommate.service;

import com.project.roommate.dto.MatchDto;
import com.project.roommate.entity.Profile;
import com.project.roommate.repository.ProfileRepository;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class MatchServiceImpl implements MatchService {

    private final ProfileRepository profileRepository;

    public MatchServiceImpl(ProfileRepository profileRepository) {
        this.profileRepository = profileRepository;
    }

    @Override
    public List<MatchDto> findMatchesForUser(String email) {
        return findMatchesForUserWithFilters(email, null, null, null);
    }

    @Override
    public List<MatchDto> findMatchesForUserWithFilters(String email, String gender, Integer maxBudget, String city) {
        Profile currentProfile = profileRepository.findByUserEmail(email).orElse(null);
        if (currentProfile == null) {
            return Collections.emptyList();
        }

        List<Profile> allProfiles = profileRepository.findAll();
        List<MatchDto> matches = new ArrayList<>();

        for (Profile potentialMatch : allProfiles) {
            // Do not match with self
            if (potentialMatch.getId().equals(currentProfile.getId())) {
                continue;
            }

            // Apply Filters
            if (gender != null && !gender.isEmpty() && !potentialMatch.getUser().getGender().equalsIgnoreCase(gender)) {
                continue;
            }
            if (maxBudget != null && potentialMatch.getBudget() != null && potentialMatch.getBudget() > maxBudget) {
                continue;
            }
            if (city != null && !city.isEmpty() && !potentialMatch.getCity().equalsIgnoreCase(city)) {
                continue;
            }

            int score = calculateMatchScore(currentProfile, potentialMatch);
            String label = getMatchLabel(score);
            
            matches.add(new MatchDto(potentialMatch, score, label));
        }

        Collections.sort(matches); // Sorted descending
        return matches;
    }

    private int calculateMatchScore(Profile p1, Profile p2) {
        int score = 0;

        // Same city = +10
        if (p1.getCity() != null && p2.getCity() != null && p1.getCity().equalsIgnoreCase(p2.getCity())) {
            score += 10;
        }

        // Similar budget = +15 (difference <= 2000)
        if (p1.getBudget() != null && p2.getBudget() != null) {
            if (Math.abs(p1.getBudget() - p2.getBudget()) <= 2000) {
                score += 15;
            } else if (Math.abs(p1.getBudget() - p2.getBudget()) <= 5000) {
                score += 5; // partially close
            }
        }

        // Similar sleep time = +15 (within 1 hour)
        if (isTimeWithinOneHour(p1.getSleepTime(), p2.getSleepTime())) {
            score += 15;
        }

        // Similar wake time = +10 (within 1 hour)
        if (isTimeWithinOneHour(p1.getWakeTime(), p2.getWakeTime())) {
            score += 10;
        }

        // Cleanliness close = +15 (difference <= 1)
        if (p1.getCleanliness() != null && p2.getCleanliness() != null) {
            if (Math.abs(p1.getCleanliness() - p2.getCleanliness()) <= 1) {
                score += 15;
            }
        }

        // Study habit close = +10 (difference <= 1)
        if (p1.getStudyHabit() != null && p2.getStudyHabit() != null) {
            if (Math.abs(p1.getStudyHabit() - p2.getStudyHabit()) <= 1) {
                score += 10;
            }
        }

        // Noise tolerance close = +10 (difference <= 1)
        if (p1.getNoiseTolerance() != null && p2.getNoiseTolerance() != null) {
            if (Math.abs(p1.getNoiseTolerance() - p2.getNoiseTolerance()) <= 1) {
                score += 10;
            }
        }

        // Same smoking preference = +10
        if (p1.getSmoking() != null && p2.getSmoking() != null && p1.getSmoking().equalsIgnoreCase(p2.getSmoking())) {
            score += 10;
        }

        // Same food preference = +5
        if (p1.getFoodPreference() != null && p2.getFoodPreference() != null && p1.getFoodPreference().equalsIgnoreCase(p2.getFoodPreference())) {
            score += 5;
        }

        // Cap at 100
        return Math.min(score, 100);
    }

    private boolean isTimeWithinOneHour(String t1, String t2) {
        if (t1 == null || t2 == null || t1.isEmpty() || t2.isEmpty()) return false;
        try {
            LocalTime time1 = LocalTime.parse(t1);
            LocalTime time2 = LocalTime.parse(t2);
            int diffHours = Math.abs(time1.getHour() - time2.getHour());
            // handle midnight wrap around (23:00 vs 00:00)
            if (diffHours > 12) {
                diffHours = 24 - diffHours;
            }
            return diffHours <= 1;
        } catch (DateTimeParseException e) {
            return false;
        }
    }

    private String getMatchLabel(int score) {
        if (score >= 85) return "Excellent Match";
        if (score >= 70) return "Good Match";
        if (score >= 50) return "Moderate Match";
        return "Low Match";
    }
}
