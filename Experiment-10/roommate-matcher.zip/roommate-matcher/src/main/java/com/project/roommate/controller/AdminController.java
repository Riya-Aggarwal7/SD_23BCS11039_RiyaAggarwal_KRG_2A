package com.project.roommate.controller;

import com.project.roommate.repository.ProfileRepository;
import com.project.roommate.repository.RoommateRequestRepository;
import com.project.roommate.repository.UserRepository;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    private final UserRepository userRepository;
    private final ProfileRepository profileRepository;
    private final RoommateRequestRepository requestRepository;

    public AdminController(UserRepository userRepository, ProfileRepository profileRepository, RoommateRequestRepository requestRepository) {
        this.userRepository = userRepository;
        this.profileRepository = profileRepository;
        this.requestRepository = requestRepository;
    }

    @GetMapping("/admin/dashboard")
    public String adminDashboard(Model model) {
        long totalUsers = userRepository.count();
        long activeProfiles = profileRepository.count();
        long totalRequests = requestRepository.count();
        
        model.addAttribute("totalUsers", totalUsers);
        model.addAttribute("activeProfiles", activeProfiles);
        model.addAttribute("totalRequests", totalRequests);
        model.addAttribute("users", userRepository.findAll());
        
        return "admin-dashboard";
    }
}
