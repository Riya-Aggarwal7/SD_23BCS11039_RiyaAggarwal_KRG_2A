package com.project.roommate.service;

import com.project.roommate.entity.RoommateRequest;

import java.util.List;

public interface RoommateRequestService {
    void sendRequest(String senderEmail, Long receiverId);
    void acceptRequest(String userEmail, Long requestId);
    void rejectRequest(String userEmail, Long requestId);
    void cancelRequest(String userEmail, Long requestId);
    
    List<RoommateRequest> getSentRequests(String email);
    List<RoommateRequest> getReceivedRequests(String email);
}
