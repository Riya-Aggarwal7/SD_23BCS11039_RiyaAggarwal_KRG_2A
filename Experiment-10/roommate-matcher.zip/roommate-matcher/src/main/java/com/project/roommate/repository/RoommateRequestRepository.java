package com.project.roommate.repository;

import com.project.roommate.entity.RoommateRequest;
import com.project.roommate.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RoommateRequestRepository extends JpaRepository<RoommateRequest, Long> {
    List<RoommateRequest> findBySenderOrderByCreatedAtDesc(User sender);
    List<RoommateRequest> findByReceiverOrderByCreatedAtDesc(User receiver);
    Optional<RoommateRequest> findBySenderAndReceiver(User sender, User receiver);
}
