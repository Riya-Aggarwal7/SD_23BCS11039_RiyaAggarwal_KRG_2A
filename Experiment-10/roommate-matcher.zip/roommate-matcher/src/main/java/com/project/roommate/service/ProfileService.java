package com.project.roommate.service;

import com.project.roommate.dto.ProfileDto;
import com.project.roommate.entity.Profile;

public interface ProfileService {
    Profile getProfileByUserId(Long userId);
    Profile getProfileByUserEmail(String email);
    void saveOrUpdateProfile(String email, ProfileDto profileDto);
}
