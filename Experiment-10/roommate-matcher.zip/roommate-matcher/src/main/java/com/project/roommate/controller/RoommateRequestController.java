package com.project.roommate.controller;

import com.project.roommate.service.RoommateRequestService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class RoommateRequestController {

    private final RoommateRequestService requestService;

    public RoommateRequestController(RoommateRequestService requestService) {
        this.requestService = requestService;
    }

    @GetMapping("/requests")
    public String viewRequests(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String email = auth.getName();
        
        model.addAttribute("receivedRequests", requestService.getReceivedRequests(email));
        model.addAttribute("sentRequests", requestService.getSentRequests(email));
        
        return "requests";
    }

    @PostMapping("/request/send")
    public String sendRequest(@RequestParam Long receiverId) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        requestService.sendRequest(auth.getName(), receiverId);
        return "redirect:/requests?sent";
    }

    @PostMapping("/request/accept")
    public String acceptRequest(@RequestParam Long requestId) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        requestService.acceptRequest(auth.getName(), requestId);
        return "redirect:/requests?accepted";
    }

    @PostMapping("/request/reject")
    public String rejectRequest(@RequestParam Long requestId) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        requestService.rejectRequest(auth.getName(), requestId);
        return "redirect:/requests?rejected";
    }
    
    @PostMapping("/request/cancel")
    public String cancelRequest(@RequestParam Long requestId) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        requestService.cancelRequest(auth.getName(), requestId);
        return "redirect:/requests?cancelled";
    }
}
