package com.project.roommate.service;

import com.project.roommate.dto.ProfileDto;
import com.project.roommate.entity.Profile;
import com.project.roommate.entity.User;
import com.project.roommate.repository.ProfileRepository;
import com.project.roommate.repository.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Service
public class ProfileServiceImpl implements ProfileService {

    private final ProfileRepository profileRepository;
    private final UserRepository userRepository;

    @Value("${app.upload.dir}")
    private String uploadDir;

    public ProfileServiceImpl(ProfileRepository profileRepository, UserRepository userRepository) {
        this.profileRepository = profileRepository;
        this.userRepository = userRepository;
    }

    @Override
    public Profile getProfileByUserId(Long userId) {
        return profileRepository.findByUserId(userId).orElse(null);
    }

    @Override
    public Profile getProfileByUserEmail(String email) {
        return profileRepository.findByUserEmail(email).orElse(null);
    }

    @Override
    public void saveOrUpdateProfile(String email, ProfileDto profileDto) {
        User user = userRepository.findByEmail(email).orElseThrow(() -> new RuntimeException("User not found"));
        Profile profile = profileRepository.findByUserId(user.getId()).orElse(new Profile());

        profile.setUser(user);
        profile.setAge(profileDto.getAge());
        profile.setOccupation(profileDto.getOccupation());
        profile.setCity(profileDto.getCity());
        profile.setPreferredArea(profileDto.getPreferredArea());
        profile.setBudget(profileDto.getBudget());
        
        profile.setSleepTime(profileDto.getSleepTime());
        profile.setWakeTime(profileDto.getWakeTime());
        
        profile.setCleanliness(profileDto.getCleanliness());
        profile.setStudyHabit(profileDto.getStudyHabit());
        profile.setNoiseTolerance(profileDto.getNoiseTolerance());
        
        profile.setSmoking(profileDto.getSmoking());
        profile.setDrinking(profileDto.getDrinking());
        profile.setGuestFrequency(profileDto.getGuestFrequency());
        
        profile.setFoodPreference(profileDto.getFoodPreference());
        profile.setGenderPreference(profileDto.getGenderPreference());
        profile.setBio(profileDto.getBio());

        // Handle Image Upload
        if (profileDto.getProfileImage() != null && !profileDto.getProfileImage().isEmpty()) {
            String fileName = StringUtils.cleanPath(profileDto.getProfileImage().getOriginalFilename());
            String uniqueFileName = UUID.randomUUID().toString() + "_" + fileName;
            
            try {
                Path uploadPath = Paths.get(uploadDir);
                if (!Files.exists(uploadPath)) {
                    Files.createDirectories(uploadPath);
                }
                
                try (InputStream inputStream = profileDto.getProfileImage().getInputStream()) {
                    Path filePath = uploadPath.resolve(uniqueFileName);
                    Files.copy(inputStream, filePath, StandardCopyOption.REPLACE_EXISTING);
                }
                
                profile.setImagePath(uniqueFileName);
                
            } catch (IOException e) {
                throw new RuntimeException("Could not save image file: " + fileName, e);
            }
        }

        profileRepository.save(profile);
    }
}
