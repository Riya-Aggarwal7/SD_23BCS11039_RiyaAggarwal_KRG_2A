package com.project.roommate.service;

import com.project.roommate.dto.UserRegistrationDto;
import com.project.roommate.entity.User;

public interface UserService {
    User save(UserRegistrationDto registrationDto);
    User findByEmail(String email);
    boolean existsByEmail(String email);

    User getUserById(Long id);
}
