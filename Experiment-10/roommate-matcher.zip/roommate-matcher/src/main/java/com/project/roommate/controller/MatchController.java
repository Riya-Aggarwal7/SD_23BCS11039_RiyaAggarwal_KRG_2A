package com.project.roommate.controller;

import com.project.roommate.dto.MatchDto;
import com.project.roommate.service.MatchService;
import com.project.roommate.service.ProfileService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class MatchController {

    private final MatchService matchService;
    private final ProfileService profileService;

    public MatchController(MatchService matchService, ProfileService profileService) {
        this.matchService = matchService;
        this.profileService = profileService;
    }

    @GetMapping("/matches")
    public String viewMatches(@RequestParam(required = false) String gender,
                              @RequestParam(required = false) Integer maxBudget,
                              @RequestParam(required = false) String city,
                              Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        
        // Ensure user has completed profile
        if (profileService.getProfileByUserEmail(auth.getName()) == null) {
            return "redirect:/profile/edit?setup";
        }

        List<MatchDto> matches = matchService.findMatchesForUserWithFilters(auth.getName(), gender, maxBudget, city);
        
        model.addAttribute("matches", matches);
        
        // Retain filter values in view
        model.addAttribute("selectedGender", gender);
        model.addAttribute("selectedBudget", maxBudget);
        model.addAttribute("selectedCity", city);
        
        return "matches";
    }
}
