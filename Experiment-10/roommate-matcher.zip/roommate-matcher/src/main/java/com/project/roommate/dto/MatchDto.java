package com.project.roommate.dto;

import com.project.roommate.entity.Profile;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MatchDto implements Comparable<MatchDto> {
    private Profile matchedProfile;
    private int matchScore;
    private String matchLabel;

    @Override
    public int compareTo(MatchDto o) {
        // Sort descending by score
        return Integer.compare(o.matchScore, this.matchScore);
    }
}
