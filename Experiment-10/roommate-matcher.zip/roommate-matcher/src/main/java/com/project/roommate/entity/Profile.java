package com.project.roommate.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "profiles")
public class Profile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id", nullable = false, unique = true)
    private User user;

    private Integer age;
    private String occupation;
    private String city;
    private String preferredArea;
    private Integer budget;
    
    // Format "HH:MM", e.g., "22:00" mapping to integer for calculation later or just keep as string
    private String sleepTime;
    private String wakeTime;
    
    // Ratings 1-5
    private Integer cleanliness;
    private Integer studyHabit;
    private Integer noiseTolerance;
    
    // Preferences Yes/No, etc.
    private String smoking;
    private String drinking;
    private String guestFrequency;
    
    private String foodPreference;
    private String genderPreference;
    
    @Column(columnDefinition = "TEXT")
    private String bio;
    
    private String imagePath;
}
