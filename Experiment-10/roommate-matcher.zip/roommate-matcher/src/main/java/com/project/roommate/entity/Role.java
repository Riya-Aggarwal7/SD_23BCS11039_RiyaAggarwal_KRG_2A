package com.project.roommate.entity;

public enum Role {
    USER,
    ADMIN
}
