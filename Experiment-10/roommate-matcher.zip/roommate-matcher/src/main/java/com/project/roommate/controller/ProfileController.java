package com.project.roommate.controller;

import com.project.roommate.dto.ProfileDto;
import com.project.roommate.entity.Profile;
import com.project.roommate.entity.User;
import com.project.roommate.repository.UserRepository;
import com.project.roommate.service.ProfileService;
import com.project.roommate.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.project.roommate.entity.User;
@Controller
public class ProfileController {

    private final ProfileService profileService;
    private final UserRepository userRepository;
    @Autowired
    private UserService userService;
    public ProfileController(ProfileService profileService, UserRepository userRepository) {
        this.profileService = profileService;
        this.userRepository = userRepository;
    }

    @GetMapping("/dashboard")
    public String dashboard(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        User user = userRepository.findByEmail(auth.getName()).orElseThrow();
        Profile profile = profileService.getProfileByUserId(user.getId());
        
        model.addAttribute("user", user);
        model.addAttribute("profile", profile);
        
        if (profile == null) {
            return "redirect:/profile/edit?setup";
        }
        
        return "dashboard";
    }

    @GetMapping("/profile/edit")
    public String editProfile(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        Profile profile = profileService.getProfileByUserEmail(auth.getName());
        
        ProfileDto profileDto = new ProfileDto();
        if (profile != null) {
            profileDto.setAge(profile.getAge());
            profileDto.setOccupation(profile.getOccupation());
            profileDto.setCity(profile.getCity());
            profileDto.setPreferredArea(profile.getPreferredArea());
            profileDto.setBudget(profile.getBudget());
            profileDto.setSleepTime(profile.getSleepTime());
            profileDto.setWakeTime(profile.getWakeTime());
            profileDto.setCleanliness(profile.getCleanliness());
            profileDto.setStudyHabit(profile.getStudyHabit());
            profileDto.setNoiseTolerance(profile.getNoiseTolerance());
            profileDto.setSmoking(profile.getSmoking());
            profileDto.setDrinking(profile.getDrinking());
            profileDto.setGuestFrequency(profile.getGuestFrequency());
            profileDto.setFoodPreference(profile.getFoodPreference());
            profileDto.setGenderPreference(profile.getGenderPreference());
            profileDto.setBio(profile.getBio());
            profileDto.setExistingImagePath(profile.getImagePath());
        }
        
        model.addAttribute("profileDto", profileDto);
        return "profile-edit";
    }

    @PostMapping("/profile/edit")
    public String saveProfile(@ModelAttribute("profileDto") ProfileDto profileDto) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        profileService.saveOrUpdateProfile(auth.getName(), profileDto);
        return "redirect:/dashboard?success";
    }

    @GetMapping("/profile/{id}")
    public String viewProfileDetails(@PathVariable Long id, Model model) {

        Profile profile = profileService.getProfileByUserId(id);

        if (profile == null) {
            return "redirect:/matches?error=profilenotfound";
        }

        User user = userService.getUserById(id);

        model.addAttribute("profile", profile);
        model.addAttribute("user", user);

        return "user-details";
    }
}
