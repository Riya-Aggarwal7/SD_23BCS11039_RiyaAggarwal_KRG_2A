package com.project.roommate.config;

import com.project.roommate.entity.Role;
import com.project.roommate.entity.User;
import com.project.roommate.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitializer {

    @Bean
    public CommandLineRunner loadData(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        return args -> {
            if (!userRepository.existsByEmail("admin@roommate.com")) {
                User admin = new User();
                admin.setName("System Admin");
                admin.setEmail("admin@roommate.com");
                admin.setPassword(passwordEncoder.encode("admin123"));
                admin.setPhone("9999999999");
                admin.setGender("OTHER");
                admin.setRole(Role.ADMIN);
                userRepository.save(admin);
            }
        };
    }
}
