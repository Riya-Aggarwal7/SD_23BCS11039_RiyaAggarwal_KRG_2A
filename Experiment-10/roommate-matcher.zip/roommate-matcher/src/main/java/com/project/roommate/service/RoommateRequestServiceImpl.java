package com.project.roommate.service;

import com.project.roommate.entity.RoommateRequest;
import com.project.roommate.entity.User;
import com.project.roommate.repository.RoommateRequestRepository;
import com.project.roommate.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class RoommateRequestServiceImpl implements RoommateRequestService {

    private final RoommateRequestRepository requestRepository;
    private final UserRepository userRepository;

    public RoommateRequestServiceImpl(RoommateRequestRepository requestRepository, UserRepository userRepository) {
        this.requestRepository = requestRepository;
        this.userRepository = userRepository;
    }

    @Override
    public void sendRequest(String senderEmail, Long receiverId) {
        User sender = userRepository.findByEmail(senderEmail).orElseThrow();
        User receiver = userRepository.findById(receiverId).orElseThrow();

        if (sender.getId().equals(receiver.getId())) {
            throw new IllegalArgumentException("Cannot send request to yourself");
        }

        Optional<RoommateRequest> existing = requestRepository.findBySenderAndReceiver(sender, receiver);
        if (existing.isPresent()) {
            RoommateRequest request = existing.get();
            if (request.getStatus() == RoommateRequest.RequestStatus.CANCELLED || request.getStatus() == RoommateRequest.RequestStatus.REJECTED) {
                request.setStatus(RoommateRequest.RequestStatus.PENDING);
                requestRepository.save(request);
            }
            return;
        }

        RoommateRequest request = new RoommateRequest();
        request.setSender(sender);
        request.setReceiver(receiver);
        request.setStatus(RoommateRequest.RequestStatus.PENDING);
        
        requestRepository.save(request);
    }

    @Override
    public void acceptRequest(String userEmail, Long requestId) {
        User user = userRepository.findByEmail(userEmail).orElseThrow();
        RoommateRequest request = requestRepository.findById(requestId).orElseThrow();

        if (!request.getReceiver().getId().equals(user.getId())) {
            throw new IllegalArgumentException("Not authorized to accept this request");
        }

        request.setStatus(RoommateRequest.RequestStatus.ACCEPTED);
        requestRepository.save(request);
    }

    @Override
    public void rejectRequest(String userEmail, Long requestId) {
        User user = userRepository.findByEmail(userEmail).orElseThrow();
        RoommateRequest request = requestRepository.findById(requestId).orElseThrow();

        if (!request.getReceiver().getId().equals(user.getId())) {
            throw new IllegalArgumentException("Not authorized to reject this request");
        }

        request.setStatus(RoommateRequest.RequestStatus.REJECTED);
        requestRepository.save(request);
    }

    @Override
    public void cancelRequest(String userEmail, Long requestId) {
        User user = userRepository.findByEmail(userEmail).orElseThrow();
        RoommateRequest request = requestRepository.findById(requestId).orElseThrow();

        if (!request.getSender().getId().equals(user.getId())) {
            throw new IllegalArgumentException("Not authorized to cancel this request");
        }

        request.setStatus(RoommateRequest.RequestStatus.CANCELLED);
        requestRepository.save(request);
    }

    @Override
    public List<RoommateRequest> getSentRequests(String email) {
        User sender = userRepository.findByEmail(email).orElseThrow();
        return requestRepository.findBySenderOrderByCreatedAtDesc(sender);
    }

    @Override
    public List<RoommateRequest> getReceivedRequests(String email) {
        User receiver = userRepository.findByEmail(email).orElseThrow();
        return requestRepository.findByReceiverOrderByCreatedAtDesc(receiver);
    }
}
