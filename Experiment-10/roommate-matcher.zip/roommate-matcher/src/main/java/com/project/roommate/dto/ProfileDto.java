package com.project.roommate.dto;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class ProfileDto {
    private Long id;
    
    private Integer age;
    private String occupation;
    private String city;
    private String preferredArea;
    private Integer budget;
    
    private String sleepTime;
    private String wakeTime;
    
    private Integer cleanliness;
    private Integer studyHabit;
    private Integer noiseTolerance;
    
    private String smoking;
    private String drinking;
    private String guestFrequency;
    
    private String foodPreference;
    private String genderPreference;
    
    private String bio;
    
    private MultipartFile profileImage;
    private String existingImagePath;
}
