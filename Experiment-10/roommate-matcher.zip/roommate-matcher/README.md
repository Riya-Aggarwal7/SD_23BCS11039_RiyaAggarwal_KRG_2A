# PG / Hostel Roommate Matcher
A complete production-style full-stack web application designed to help students and working professionals find the most compatible roommates based on lifestyle, habits, and budget.

## Tech Stack
- **Backend:** Java 17, Spring Boot, Spring Security, Spring Data JPA
- **Frontend:** Thymeleaf, Bootstrap 5, plain HTML/CSS/JS
- **Database:** PostgreSQL
- **Tools:** Maven, Lombok

## Setup Instructions

1. **Prerequisites**
   - Java 17 or higher
   - Maven installed (`mvn` command available)
   - PostgreSQL installed and running

2. **Database Setup**
   - Create a new PostgreSQL database:
     ```sql
     CREATE DATABASE roommate;
     ```
   - Make sure your credentials in `src/main/resources/application.properties` are correct (default is `postgres:postgres` on port `5432`).

3. **Run the Application**
   - Open terminal in the project root folder.
   - Run the Spring Boot application using Maven:
     ```bash
     mvn spring-boot:run
     ```
   - Or open the project in **IntelliJ IDEA / Eclipse**, let it resolve dependencies, and run `RoommateApplication.java`.

4. **Testing**
   - The app will run on `http://localhost:8080`
   - Access the landing page: `http://localhost:8080/`
   - Default Admin Credentials: `admin@roommate.com`, Password: `admin123`
   - Admin Panel: `http://localhost:8080/admin/dashboard`

## Features Included
1. Secure Authentication & Role based Access control.
2. Comprehensive Profile Builder with File Uploads.
3. 100-Point Smart Matching Engine considering Diet, Sleep, Budget, and Cleanliness.
4. Filter Matches seamlessly.
5. Peer-to-Peer Roommate Request workflow (Send/Accept/Reject).
6. Admin Dashboard tracking active user statistics.

## Future Improvements
- **Chat System:** Implement WebSockets for real-time messaging between matched pairs.
- **REST APIs & React:** Expose current endpoints as purely stateless REST APIs and decouple the UI into a React frontend.
- **Dockerization:** Add `Dockerfile` and `docker-compose.yml` for instantaneous, reproducible deployments.
- **Email Notifications:** Integrate JavaMailSender to notify users when their roommate requests are accepted.
